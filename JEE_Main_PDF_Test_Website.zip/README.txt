JEE Main PDF Test website
1. Open index.html in Chrome/Edge.
2. Upload the question-paper PDF.
3. The supplied JRS answer key is built into this demo, so the sample paper can be tested immediately.
4. Select answers, use Mark for review, and Submit.
5. The question PDF is rendered inside the page.

Note: this first version uses the supplied answer key as a built-in key. Automatic OCR of arbitrary image-only answer-key PDFs is the next upgrade.
